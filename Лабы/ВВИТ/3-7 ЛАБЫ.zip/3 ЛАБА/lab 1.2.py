def read_file():
    with open('example.txt', 'r') as file:
        content = file.read()
        print(content)
read_file()