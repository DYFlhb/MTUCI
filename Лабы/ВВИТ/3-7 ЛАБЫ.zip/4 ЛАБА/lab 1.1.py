import math
sqrt = math.sqrt(25)
print(sqrt)