def sum(a, b):
    print (a + b)
def min(a, b):
    print (a - b)