def remove_space(a):
    print (a.replace(" ", ""))
def reverse_str(a):
    print (a[::-1])