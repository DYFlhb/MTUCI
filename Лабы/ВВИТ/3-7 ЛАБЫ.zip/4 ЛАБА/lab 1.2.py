from datetime import *
print(datetime.now())