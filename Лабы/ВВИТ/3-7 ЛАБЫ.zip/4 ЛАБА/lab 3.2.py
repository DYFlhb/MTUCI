from packages import nums_module, txt_module

nums_module.sum(1, 5)
nums_module.min(1, 5)

txt_module.remove_space("A b c d e f g")
txt_module.reverse_str("A b c d e f g")