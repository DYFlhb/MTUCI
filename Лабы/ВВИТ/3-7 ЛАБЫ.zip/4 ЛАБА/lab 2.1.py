import my_module
my_module.summ(1, 5)