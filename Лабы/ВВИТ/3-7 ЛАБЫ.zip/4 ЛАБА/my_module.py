def summ(a, b):
    print(a + b)